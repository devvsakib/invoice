@include('_header')
<style type="text/css">
* {
    font-family: 'myFirstFont1';
}
.swal-text,.swal-button--cancel{color:#111;text-align: center;} .swal-button--catch{background-color: #009688;}.swal-button--catch:not([disabled]):hover{    background-color: #026a61;}
</style>
<!-- <form action="" id="frm1" method="post" style="margin:auto">
	
    
	<input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
	<table style="width:400px;margin:auto">
		<tr>
			<td>Email</td>
			<td><input type="text" name="email" id="email" value="{{ old('email') }}"></td>
		</tr>
		<tr>
			<td>Password</td>
			<td><input type="password" name="password" id="password" value=""></td>
		</tr>
		
		<tr>
			<td colspan="2">
				<input type="button" name="form_submit" id="form_submit" value="Submit" onclick="form_validate()">
			</td>
		</tr>
	</table>
</form> -->

<div class="container mt-5">
	@if($errors->any())
	<div class="text-center" id="msg-alert1">
	
        <div class="alert alert-danger">
	        <ul>
	            @foreach ($errors->all() as $error)
	                <p>{{ $error }}</p>
	            @endforeach
	        </ul>
	    </div>
	</div>
    @endif

	<form action="{{route('login_post')}}" id="frm1" method="post" style="max-width:100%;width:300px;margin:auto">
		<input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
	  <div class="mb-3">
	    <label for="exampleInputEmail1" class="form-label">{{$lang_kwords['email']['english']}}</label>
	    <input type="text" class="form-control" name="email" id="email" value="{{ old('email') }}">
	  </div>
	  <div class="mb-3">
	    <label for="exampleInputPassword1" class="form-label">{{$lang_kwords['passwords']['english']}}</label>
	    <input type="password" class="form-control" name="password" id="password" value="">
	  </div>
	  <!-- <div class="mb-3 form-check">
	    <input type="checkbox" class="form-check-input" id="exampleCheck1">
	    <label class="form-check-label" for="exampleCheck1">Check me out</label>
	  </div> -->
	  <div class="text-center">
	  	<button type="button" style="width:100%" class="btn btn-primary" name="form_submit" id="form_submit" onclick="form_validate()">{{$lang_kwords['login_submit']['english']}}</button>
	  </div>
	  <div class="text-center">
	  	<p class="mt-2"><span class="text-primary" role="button" onclick="show_forget_pass()">{{$lang_kwords['forgot-password']['english']}}</span></p>
	  </div>
	</form>

	<div class="text-center" id="fp_er_sec" style="display:none">
        <div class="alert alert-danger">
			<p id="fp_er_p"></p>
	    </div>
	</div>

	<form action="" id="frm2" method="post" style="max-width:100%;width:300px;margin:auto;display:none">
		<input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
		<input type="hidden" name="act" value="c">
		<input type="hidden" name="lt" value="en">
	  <div class="mb-3">
	    <label for="exampleInputEmail1" class="form-label">{{$lang_kwords['email']['english']}}</label>
	    <input type="text" class="form-control" name="email" id="email1" value="">
	  </div>
	  
	  <div class="text-center">
	  	<button type="button" style="width:100%" class="btn btn-primary" name="form_submit" id="form_submit1" onclick="form_validate1()">{{$lang_kwords['submit']['english']}}</button>
	  </div>
	  <div class="text-center">
	  	<p class="mt-3"><span class="text-primary" role="button" onclick="show_login()">{{$lang_kwords['go-to-login']['english']}}</span></p>
	  </div>
	</form>
	<div class="text-center mt-5">
	    <!-- <p>Not a member? <a href="{{route('register')}}">Register</a></p> -->
	    @if(isset($contents['register_section']))
                {!! $contents['register_section']['content'] !!}
        @endif   
	    
  	</div>

</div>

@include('salon/footer')
<script src="{{URL::asset('public/js/sweetalert.min.js')}} "></script>

<script type="text/javascript">

	setTimeout(function(){
		$('#msg-alert1').hide();
	},5000);

	function form_validate(){
		
		var email = $('#email').val();	
		var password = $('#password').val();	

		if($.trim(email)==''){
			$('#email').focus();
			return false;
		}
		if($.trim(password)==''){
			$('#password').focus();
			return false;
		}

		$('#frm1').submit();
	}

	function show_forget_pass(){
		$('#frm1').hide();
		$('#email').val('');
		$('#password').val('');
		$('#frm2').show();
	}

	function show_login(){
		$('#frm1').show();
		$('#email1').val('');
		$('#frm2').hide();
	}

	function form_validate1(){
		$('#fp_er_sec').hide();
		var email = $('#email1').val();	
		if($.trim(email)==''){
			$('#email1').focus();
			return false;
		}

		var frm = $('#frm2').serialize();

		$('#form_submit1').attr('disabled',true);

		$.ajax({
			url:'{{route("forget_pass")}}',
			type:'post',
			data:frm,
			dataType:"json",
			success:function(r){
				if(r.status=='SUCCESS'){
					show_msg();
				}
				else{
					$('#form_submit1').attr('disabled',false);
					$('#fp_er_sec').show();
					if(r.msg=='Not found'){
						$('#fp_er_p').html('{{$lang_kwords["email-not-found"]["english"]}}');
					}
					else{
						$('#fp_er_p').html('{{$lang_kwords["incorrect_email"]["english"]}}');
					}
				}
				
			},
			error:function(){
				$('#form_submit1').attr('disabled',false);
			}
		})
	}

	function show_msg(){
	    swal(
	      "{{$lang_kwords['password-reset-link-send']['english']}}",
	      {
	        buttons: {
	          catch: {
	            text: "{{$lang_kwords['alert_ok']['english']}}",
	          },
	          defeat: false,
	        },
	      }
	    )
	    .then((value) => {
	      switch (value) {
	     
	        case "defeat":
	          swal("Got away safely!");
	          break;
	     
	        case "catch":
	          location.reload();
	          break;
	     
	        default:
	          // swal("Got away safely!");
	          return false;
	      }
	    });
	}

</script>
</body>
</html>